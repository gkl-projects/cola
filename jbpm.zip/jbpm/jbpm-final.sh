#!/bin/bash

#script tells shell to install softwares here

apt-get update

apt-get install firefox -y

apt-get install eclipse -y

apt-get install geany -y

apt-get install xrdp -y

apt-get install icewm -y

apt-get install idesk -y

apt-get install dpkg -y

apt-get install rox-filer -y

apt-get install scp -y

apt-get install xterm -y

apt-get install zip -y

apt-get install unzip -y

apt-get install nautilus -y

apt-get install apache2 -y

systemctl stop apache2.service

systemctl start apache2.service

systemctl enable apache2.service

#here script perfoms links to logos:-

cp jbpm.png /usr/share/pixmaps

ln -s /usr/share/icons/hicolor/16x16/apps/firefox.png /usr/share/pixmaps/firefox.png

ln -s /usr/share/icons/hicolor/16x16/apps/geany.png /usr/share/pixmaps/geany.png

#hear script perform directory struchure:-

mkdir /home/ubuntu/backup

mkdir /home/ubuntu/backup/handson
mkdir /home/ubuntu/backup/slides
mkdir /home/ubuntu/backup/outline
mkdir /home/ubuntu/backup/backup

touch /home/ubuntu/backup/instructions

cp menu /usr/share/icewm/menu 

mkdir /home/ubuntu/.icewm

mkdir /home/ubuntu/.idesktop

cp -a .icons /home/ubuntu

cp .ideskrc /home/ubuntu/.ideskrc

cp .ideskrc /home/ubuntu/.icewm/

cp .idesktop/* /home/ubuntu/.idesktop

echo "idesk >> /tmp/idesklog &" > /home/ubuntu/.icewm/startup

chmod +x /home/ubuntu/.icewm/startup 

#here the script tells shell to install java:-

apt-get update

apt install openjdk-8-jre-headless -y

export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64

export PATH=$JAVA_HOME/bin:$PATH

#here the script tells shell to install ant:-

apt-get install ant -y
	
wget http://www-eu.apache.org/dist//ant/binaries/apache-ant-1.9.13-bin.tar.gz

tar -xf apache-ant-1.9.13-bin.tar.gz  -C /usr/local

ln -s /usr/local/apache-ant-1.9.13/ /usr/local/ant

echo "export ANT_HOME=/usr/local/ant" > /etc/profile.d/ant.sh

echo "export PATH=${ANT_HOME}/bin:${PATH}" > /etc/profile.d/ant.sh

chmod +x /etc/profile.d/ant.sh

source /etc/profile.d/ant.sh

#here the script tells shell to install jbpm 

wget https://nchc.dl.sourceforge.net/project/jbpm/jBPM%206/jbpm-6.3.0.Final/jbpm-6.3.0.Final-installer-full.zip

unzip jbpm-6.3.0.Final-installer-full.zip 

chown -R ubuntu:ubuntu jbpm-installer

mv jbpm-installer /home/ubuntu

exit 0






