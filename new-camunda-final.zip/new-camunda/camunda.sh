#!/bin/bash

#script tells shell to install softwares here

apt-get update

apt-get install firefox eclipse geany -y
apt-get install xrdp icewm idesk dpkg rox-filer scp -y
apt-get install xterm zip unzip nautilus -y

#here script install php-bind and apache2:-

apt-get install apache2 -y

systemctl stop apache2.service

systemctl start apache2.service

systemctl enable apache2.service

#script create linkfiles:-

cp camunda.jpg /usr/share/pixmaps

ln -s /usr/share/icons/hicolor/16x16/apps/firefox.png /usr/share/pixmaps/firefox.png

ln -s /usr/share/icons/hicolor/16x16/apps/geany.png /usr/share/pixmaps/geany.png

#hear script perform directory struchure:-

mkdir -p /home/ubuntu/backup/{handson,slides,outline,backup}

chown -R ubuntu:ubuntu /home/ubuntu/backup

touch /home/ubuntu/backup/instructions

chown -R ubuntu:ubuntu /home/ubuntu/backup/instructions

cp menu /usr/share/icewm/menu 

mkdir -p /home/ubuntu/{.icewm,.idesktop}

cp -a .icons /home/ubuntu

chown -R ubuntu:ubuntu /home/ubuntu/.icons

cp .ideskrc /home/ubuntu/.ideskrc

chown -R ubuntu:ubuntu /home/ubuntu/.ideskrc

touch /home/ubuntu/.icewm/.ideskrc

chown -R ubuntu:ubuntu /home/ubuntu/.icewm/.ideskrc

cp .idesktop/* /home/ubuntu/.idesktop

echo "idesk >> /tmp/idesklog &" > /home/ubuntu/.icewm/startup

chmod +x /home/ubuntu/.icewm/startup 

chown -R /home/ubuntu/.icewm/startup

echo "FocusMode=0" > /home/ubuntu/.icewm/focus_mode

chown -R ubuntu:ubuntu /home/ubuntu/.icewm/focus_mode
                            
chown -R ubuntu:ubuntu /home/ubuntu/{.icewm,.idesktop}

#here the script perform camunda install

wget https://camunda.org/release/camunda-bpm/tomcat/7.8/camunda-bpm-tomcat-7.8.0.tar.gz
 
tar -xzf camunda-bpm-tomcat-7.8.0.tar.gz -C /home/ubuntu

chown -R ubuntu:ubuntu /home/ubuntu/{start-camunda.sh,server,sql,lib}

echo -e "ub4ntu4\nub4ntu4" | (passwd ubuntu)

exit 0

